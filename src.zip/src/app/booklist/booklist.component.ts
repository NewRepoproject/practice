import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {
  bookarr:Book[]
  bookdao:BookdaoService;
  // service ma sa ng on init ma populate karna ha 

  constructor(bookdao:BookdaoService,private router:Router) {
    this.bookarr=[];
    this.bookdao=bookdao;
   }

  ngOnInit(): void {
    this.bookdao.getAllBooks().subscribe(
      // (data):void=>{
        (data:Book[])=>{
        console.log(data);
        this.bookarr =data;
      }
    )
    // because we are putting ngfor thatwhy populated 
  }

  getAllBooks()
  {
    this.bookdao.getAllBooks().subscribe(
      // (data):void=>{
        (data:Book[])=>{
        console.log(data);
        this.bookarr =data;
      }
    )
      }


  deleteBook(bookid:number)
  {
    this.bookdao.deleteBook(bookid).subscribe(
      ()=>{
        console.log('book with bookid:'+bookid+ 'is deleted');
        //  this.getAllBooks();
       
      }

    )
    this.router.navigate(['/listbooks']);
    this.getAllBooks();
  }
  
  updateBook(id:number)
  {
this.router.navigate(['update-bookdetails',id]);
  }
//   updateBook(id:number)
//   {
// this.router.navigate(['updatebook',id]);
//   }


  // SearchText: string='';
  // onSearchTextEntered(searchBook:string){
  //   this.SearchText=searchBook;
  //   console.log(this.SearchText);
  // }
}
