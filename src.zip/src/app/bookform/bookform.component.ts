import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-bookform',
  templateUrl: './bookform.component.html',
  styleUrls: ['./bookform.component.css']
})
export class BookformComponent {

  book:Book;
  bookdao:BookdaoService;
  constructor(bookdao:BookdaoService,private router:Router){
    this.bookdao = bookdao;
    this.book = new Book(1,'','');
  }

  submitform(form:any){
    console.log('book form submitted');
    console.log(this.book);
    this.bookdao.addBook(this.book).subscribe(
      { complete: () => {console.log('addbook post completed..') }, // completeHandler
       error: (error) => { console.log(error) },    // errorHandler 
       next: (response) => { console.log('book added successfully')  }
      } )
      this.router.navigateByUrl('/listbooks')
  }

  resetBook():void{
    //this.book = new Book(-1,'','');
  }

}
