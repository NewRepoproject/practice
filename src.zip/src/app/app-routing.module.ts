import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookformComponent } from './bookform/bookform.component';
import { BooklistComponent } from './booklist/booklist.component';
import { SearchComponent } from './search/search.component';
import { UpdatebookComponent } from './updatebook/updatebook.component';

const routes: Routes = [
  {
    path:'addBook',
    component:BookformComponent
  },
  {
    path:'listbooks',
    component:BooklistComponent
  },
  {
    path:'update/:id/:name/:author',
    component:UpdatebookComponent
  },
  {
    path:'search',
    component:SearchComponent
  },
  {
    path:'home',
    redirectTo:'',
    pathMatch:'full'
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
