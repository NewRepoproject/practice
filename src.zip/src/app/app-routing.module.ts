import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookformComponent } from './bookform/bookform.component';
import { BooklistComponent } from './booklist/booklist.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { SearchComponent } from './search/search.component';
import { UpdateBookdetailsComponent } from './update-bookdetails/update-bookdetails.component';

const routes: Routes = [
  {
    path:'addBook',
    component:BookformComponent
  },
  {
    path:'listbooks',
    component:BooklistComponent
  },
  {
    path:'',
    redirectTo:'addBook',
    pathMatch:'full'
  },
  {
    path:'update-bookdetails/:id',
    component:UpdateBookdetailsComponent,
    // pathMatch:'full'
  },
  {
    path:'search',
    component:SearchComponent ,
  
    // pathMatch:'full'
  },
  {
    path:'**',
    component:PagenotfoundComponent
  },
  



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
