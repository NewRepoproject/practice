import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent {

  bookname:string;
  book!:Book;
  constructor(private bookdao:BookdaoService){
    this.bookname='';
    //this.book=new Book(1,'','');
  }

  submitform(form:any){
    this.bookdao.searchBook(this.bookname).subscribe(
      (data)=>{
        this.book = data;
      }
    )
    console.log(this.book);
  }

  
}
