import { Component, EventEmitter, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  
  bookdao: BookdaoService;
 book:Book;
 bookIdValue:any;
 searchText: any;
 bookarr:Book[];
  constructor(bookdao: BookdaoService) {

    this.book = new Book(1, '', '');
    this.bookdao = bookdao;
    this.bookarr=[]
    this.bookIdValue = undefined;

  }

  ngOnInit(): void {

    this.bookdao.getAllBooks().subscribe(
      (data: Book[]) => {
        console.log(data);
        this.bookarr = data;
      }
    );
  }

      getBookByname(name:string) {
      this.bookdao.getBookByName(name).subscribe(
      (data: Book[]) => {
        console.log(data);
        this.bookarr = data;
      }
    )
      }
    


      // getBook(bookid: Number) {
      //   console.log();
      //   // this.bookdao.getBookById(bookid).subscribe(
      //     (data: Book) => {
      //       console.log(data);
      //       this.book = data;
      //     },
      //     (error) => {
      //       console.log(error);
      //     }
      //   )
      // }

  }
  // // ngOnInit(): void {
  // //   throw new Error('Method not implemented.');
  // // }
  // book:Book;
  // bookarr:Book[];
  // bookdao:BookdaoService;
  // searchText:any
  // // router: any;

  // constructor(bookdao:BookdaoService) { 
  //   this.book=new Book(1,'','');
  //   // this.book = new Book(+BookdaoService+1,'','');
  //   this.bookdao=bookdao;
  //   this.bookarr=[];
  // }
  //   ngOnInit(): void {
  //   this.bookdao.getAllBooks().subscribe(
  //     (data: Book[]) => {
  //       console.log(data);
  //       this.bookarr = data;
  //     }
  //   );
  // }

  // getBookByname(name:string) {

  //   this.bookdao.getBookByName(name).subscribe(
  //     (data: Book) => {
  //       console.log(data);
  //       this.book = data;
  //     }
  //   );
  //     }

      // getBook(id: Number) {
      //   console.log();
      //   this.bookdao.getBook(id).subscribe(
      //     (data: Book) => {
      //       console.log(data);
      //       this.book = data;
          
      //     },
      //     (error) => {

      //       console.log(error);

      //     }

      //   )

      // }

 

// }

//   ngOnInit(): void {
//     this.bookdao.getAllBooks().subscribe(

//       (data: Book[]) => {

//         console.log(data);

//         this.bookarr = data;

//       }
//     );
//   }
// }

  // enteredSearchValue: string="";
  // searchTextChange:EventEmitter<string>=new EventEmitter<string>();
  // onSearchTextChanged(){
  //   this.searchTextChange.emit(this.enteredSearchValue);
  // }

  



  // name="";
  // employee:any;

  // OnClick(){
  //   this.bookdao.getBookByName(this.book)
  //   .subscribe((data) => {this.book=data;
  //     if(this.book.length !=0 ){
  //       this.router.navigate(["view",this.name]);
  //     } else{
  //       this.name="";
  //       this.messageService.showErrorMessage("Oops!","No record found");
  //     }   
  //   },
  //   (error)=> {this.messageService.showErrorMessage("Oops! Something went wrong",error.name)})
  // }
  //  searchBook(bookname:string)
  //  {
  //   // this.router.navigate(['searchbook',bookname]);
  //   this.bookdao.getByName(this.book.bookname).subscribe(
  //     (data:Book[])=>{
  //       console.log(data);
  //       this.bookarr=data
  //     }

  //   )
  //  }
  // }
  // public searchEmployees(key: string): void {
  //   console.log(key);
  //   const results: Book[] = [];
  //   for (const book of this.book) {
  //     if (book.bookname.toLowerCase().indexOf(key.toLowerCase()) !== -1) {
  //       results.push(book);
  //     }
  //   }
  //   this.bookdao = results;
  //   if (results.length === 0 || !key) {
  //     this.getAllBooks();
  //   }
  // }

