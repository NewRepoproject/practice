import { HttpClientModule } from '@angular/common/http';
import { createComponent, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BookformComponent } from './bookform/bookform.component';
import { BooklistComponent } from './booklist/booklist.component';
import { HomeComponent } from './home/home.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { UpdateBookdetailsComponent } from './update-bookdetails/update-bookdetails.component';
import { SearchComponent } from './search/search.component';
import { BarComponent } from './bar/bar.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';


@NgModule({
  declarations: [
    AppComponent,
    // createComponent
    BookformComponent,
    BooklistComponent,
    HomeComponent,
    PagenotfoundComponent,
    UpdateBookdetailsComponent,
    SearchComponent,
    BarComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    Ng2SearchPipeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
