import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscriber } from 'rxjs';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-update-bookdetails',
  templateUrl: './update-bookdetails.component.html',
  styleUrls: ['./update-bookdetails.component.css']
})
export class UpdateBookdetailsComponent implements OnInit {
  book:Book;
  bookdao:BookdaoService;




  constructor(bookdao:BookdaoService, private router:Router) { 
    this.book=new Book(1,'','');
    // this.book = new Book(+BookdaoService+1,'','');
    this.bookdao=bookdao;
  }

  ngOnInit(): void {
    
  }
  //  submitform(form:any)
  //  {
  //   console.log('book form submitted');
  //   console.log(this.book);
  //   this.bookdao.addBook(this.book).subscribe(
  //     { complete:()=>{console.log('addbook post complete..')},//complete handler
  //      error:(error)=>{console.log(error)},
  //      next:(response)=>{console.log('book added successfully')}

  //     }

  //   )
  //   this.router.navigate(['/listbooks']);
  //   // this.book = new Book(+BookdaoService+1,'','');
  //  }


   updateform(form:any)
   {
    console.log('update form submitted');
    console.log(this.book);
    this.bookdao.updateBook(this.book).subscribe(
      { complete:()=>{console.log('updatebook post complete..')},//complete handler
       error:(error)=>{console.log(error)},
       next:(response)=>{console.log('book updated successfully')}

      }

    )
    this.router.navigate(['/listbooks']);
    // this.book = new Book(+BookdaoService+1,'','');
   }

  // updateform(form:any)
  // {
  //   this.bookdao.updateBook(this.book.bookid,this.book).subscribe(
  //     ()=>{
  //       console.log("book updated sucessfully");
  //     }
  //   )
  // }
}
