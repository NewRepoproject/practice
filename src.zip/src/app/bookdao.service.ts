import { Injectable } from '@angular/core';
import { Book } from './model/book';

import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';
import { identifierName } from '@angular/compiler';

@Injectable({
  providedIn: 'root'
})
export class BookdaoService {
  [x: string]: any;
  baseurl:string;
  httpOptions = {
    headers:new HttpHeaders({
                             'Content-Type':'application/json'
                         })
   }
  constructor(private httpClient: HttpClient) {
    console.log('bookdao service constructor called...');
     this.baseurl = 'http://localhost:8081';
  //  this.httpClient = httpClient;
   }
   addBook(b:Book)
   {
     console.log('inside addBook method...');
    return this.httpClient.post<Book>(this.baseurl+"/addBook1",JSON.stringify(b),this.httpOptions)
    .pipe(
      catchError(this.errorHandler)
      )
 
   }
   getAllBooks()
   {
    // we use asynchronus call
      return this.httpClient.get<Book[]>(this.baseurl+"/allbooks",this.httpOptions)
      .pipe(
        catchError(this.errorHandler)
      )
   }
  //  deleteBook(id:number)
  //  {
  //   // we use asynchronus call
  //     return this.httpClient.delete<Book>(this.baseurl+'/removeBook1'+'/'+id)
  //     .pipe(
  //       catchError(this.errorHandler)
  //     )
  //  }

   deleteBook(id:number)
   {
    // we use asynchronus call
      return this.httpClient.delete<Book>(this.baseurl+'/removeBook1/'+id)
      .pipe(
        catchError(this.errorHandler)
      )
   }
// -----------------------------------------
   getBookById(id:number):Observable<Book> {
    return this.httpClient.get<Book>(this.baseurl+'/book'+id,this.httpOptions).pipe(
      catchError(this.errorHandler)
    )
   }
  //  ___----------------------------------
  getBookByName(name:string)
  {
    console.log("inside getByName ...");
    return this.httpClient.get<Book[]>(this.baseurl+'/book'+name,this.httpOptions)
    .pipe(catchError(this.errorHandler))
  }
   
  // updateBook(id:number,b:Book)
  // {
  //   console.log("inside updatebook ");
  //   return this.httpClient.put<Book>(this.baseurl+"/updateBook"+id,JSON.stringify(b),this.httpOptions).pipe(
  //     catchError(this.errorHandler)
  //   )
  // }
  updateBook(b:Book)
  {
    console.log("inside updatebook ");
    return this.httpClient.put<Book>(this.baseurl+"/updateBook",JSON.stringify(b),this.httpOptions).pipe(
      catchError(this.errorHandler)
    )
  }
   errorHandler(httperror:HttpErrorResponse) {
    let errorMessage = '';
    if(httperror.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = httperror.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${httperror.status}\nMessage: ${httperror.message}`;
    }
    console.log(errorMessage);
    return throwError(() => httperror);
 }
  
}
