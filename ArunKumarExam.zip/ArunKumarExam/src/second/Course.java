package second;

public class Course {
	public String name;
	public String duration;
	
	public Course(){
		System.out.println("Default Constructor");
	}
	
	public Course(String n, String d) {
		super();
		this.name = n;
		this.duration = d;
	}
	static int calDuration(String name,int h) {
		return 24*h;
	}
	static int calDuration(String name, int h,int day)
	{
		return 24*h*day;
	}
	public static void main(String args[]) {
		Course c=new Course();
		System.out.println("Default constructor ");
		System.out.println("course name:"+c.name+"duration"+c.duration);
		
		System.out.println("Parametrised constrcutor");
		Course C1=new Course("Gate","1 year");
		System.out.println("name"+C1.name+"duration"+C1.duration);
		
		
		
		System.out.println(calDuration("JAVA",14)+"hour");
		System.out.println(calDuration("Gate",5)+"hour");
//		System.out.println()
		Course c3=null;
		System.out.println(c3 instanceof Course);
		
	}
	

}
