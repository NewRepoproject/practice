package BgroupArun;

import java.util.*;
//Collection Framework – HashMap, TreeMap , key – student , value – course
//And you have to also make use of comparator interface – sort student birthdate
//Arun Kumar
public class Student {
	public static void main(String args[])
	{
		TreeMap<String,String> hashmap=new TreeMap<String,String>(new course());
		hashmap.put("Arun","java" );
		hashmap.put("Ayush", "C++");
		hashmap.put("Arman", "python");
		hashmap.put("Mirnal","Sap");
		System.out.println(hashmap);
		
		

		
	}

	

}
