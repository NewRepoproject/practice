package BgroupArun;

import java.util.*;

public class Hash {
	
	public static HashMap<String,String>
	sortByValue(HashMap<String, String>h)
	{ 
		List<Map.Entry<String,String>> list=new LinkedList<Map.Entry<String,String> >(h.entrySet());
		 Collections.sort(
				list,
				new Comparator<Map.Entry<String,String>>(){
					public int compare(
							Map.Entry<String,String>o1,
							Map.Entry<String,String>o2)
					{
						return(o1.getValue()).compareTo(o2.getValue());
					}
				});
		 HashMap<String,String> result=new LinkedHashMap<String,String>();
		 for(Map.Entry<String,String>me:list) {
			 result.put(me.getKey(), me.getValue());
		 }
		 return result;
	}
	
public static void main(String args[]) {
	HashMap<String,String>hashmap=new HashMap<String,String>();
	hashmap.put("Arun","22yr" );
	hashmap.put("Ayush", "21yr");
	hashmap.put("Arman", "25yr");
	hashmap.put("Mirnal","27yr");
	
	Map<String,String> map=sortByValue(hashmap);
	for(Map.Entry<String,String> entry:
		map.entrySet()) {
		System.out.println("Key :" +entry.getKey()+"  value: "+entry.getValue());
	}
}

}
