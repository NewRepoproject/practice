package com.nama.springboot.firstdemo.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.nama.springboot.firstdemo.model.Employee;

@Service
public class EmployeeDao {
	
	List<Employee> empList;
	
	public EmployeeDao() {
		empList = new ArrayList<Employee>();
		empList.add(new Employee(1,"Eric"));
		empList.add(new Employee(2,"Tom"));
		empList.add(new Employee(3,"Liam"));
		empList.add(new Employee(4,"Alastair"));
	}
	
	public Employee getEmp(int empId) {
		for(Employee emp : empList) {
			if(emp.getEmpid() == empId) {
				return emp;
			}
		}
		return null;
	}
	
	public List<Employee> getEmps(){
		return empList;
	}
	
	public boolean addEmp(Employee emp) {
		return empList.add(emp);
	}
	
	public boolean removeEmp(int empId) {
		for(Employee emp : empList) {
			if(emp.getEmpid() == empId) {
				return empList.remove(emp);
			}
		}
		return false;
	}
	
	public boolean removeEmp(Employee emp) {
		return empList.remove(emp);
	}

}
