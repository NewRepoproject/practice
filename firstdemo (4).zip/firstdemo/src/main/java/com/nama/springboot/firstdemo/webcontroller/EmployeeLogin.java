package com.nama.springboot.firstdemo.webcontroller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

@SessionAttributes("empId")
@Controller
public class EmployeeLogin {
	
	@PostMapping("login")
	public String login(@RequestParam int empId, @RequestParam String password,ModelMap model) {
		if(empId == 2 & password.equalsIgnoreCase("redhat"))
		  {
			 model.addAttribute("empId",empId);
			  return "redirect:/getEmp/"+empId;
		  }
		 else
		 {
			 model.addAttribute("empId",empId);
			 model.addAttribute("errormsg","Login Invalid!");
			 return "index";
		 }
	}

}
