package com.nama.springboot.firstdemo.webcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.nama.springboot.firstdemo.dao.EmployeeDao;
import com.nama.springboot.firstdemo.model.Employee;

@Controller
public class EmpWebController {
	
	@Autowired
	EmployeeDao empDao;
	
	@GetMapping("/getEmp/{empId}")
	public String getEmp(@PathVariable int empId,ModelMap model) {
		Employee emp = empDao.getEmp(empId);
		if(emp != null) {
			model.addAttribute("empInfo",emp);
		}else {
			model.addAttribute("msg", "Emplyee with id :" +empId+" is not found");
		}
		return "emp";
	}
	
	@GetMapping("/getEmps")
	public String getEmps(Model model){
		 List<Employee> listEmps =  empDao.getEmps();
		 model.addAttribute("empList", listEmps);
		 return "emps";
	}

}
