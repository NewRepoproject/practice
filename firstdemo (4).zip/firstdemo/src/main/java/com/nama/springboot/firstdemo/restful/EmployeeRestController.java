package com.nama.springboot.firstdemo.restful;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.nama.springboot.firstdemo.dao.EmployeeDao;
import com.nama.springboot.firstdemo.model.Employee;

@RestController
public class EmployeeRestController {

	@Autowired
	EmployeeDao empDao;

	@GetMapping("/emp/{empId}")
	public ResponseEntity<Employee> getEmp(@PathVariable int empId) {
		Employee emp = empDao.getEmp(empId);
		if (emp != null) {
			return ResponseEntity.ok(emp);
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	@GetMapping("/emp")
	public List<Employee> getEmps() {
		return empDao.getEmps();
	}

	@PostMapping("/emp")
	public ResponseEntity<Employee> addEmp(@RequestBody Employee emp) {
		empDao.addEmp(emp);
		URI location = ServletUriComponentsBuilder
				.fromCurrentRequestUri()
				.path("/empId")
				.buildAndExpand(emp.getEmpid())
				.toUri();
		return ResponseEntity.created(location).build();
	}
	
	@DeleteMapping("/emp")
	public ResponseEntity<String> removeEmp(@RequestBody Employee emp){
		boolean flag = empDao.removeEmp(emp);
		if(flag) {
			return ResponseEntity.ok("Emplyee Deleted with id: "+emp.getEmpid());
		}else {
			return ResponseEntity.notFound().build();
		}
	}
	
	@DeleteMapping("/emp/{empId}")
	public ResponseEntity<String> removeEmp(@PathVariable int empId) {
		Boolean result = empDao.removeEmp(empId);
		if(result) {
			return ResponseEntity.ok("Emplyee Deleted with id: "+empId);
		}else {
			return ResponseEntity.notFound().build();
		}
	}

}
