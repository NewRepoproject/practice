package second;

public class CrashCourse extends Course{

	private double Crashcoursefees;
	private  int Crashduration;
		
		public CrashCourse() {
			
		}

		public CrashCourse(String studentname, int rollno, String courseName, double fees, int duration,double Crashcoursefees, int Crashduration) 
		{
			super(studentname, rollno, courseName, fees, duration);
			this.Crashcoursefees=Crashcoursefees;
			this.Crashduration=Crashduration;
		}
		
		
		public double getCrashcoursefees() {
			return Crashcoursefees;
		}



		public void setCrashcoursefees(double crashcoursefees) {
			this.Crashcoursefees = crashcoursefees;
		}



		public int getCrashduration() {
			return Crashduration;
		}



		public void setCrashduration(int crashduration) {
			this.Crashduration = crashduration;
		}



		@Override
		public String toString()
		{
			return super.toString()+", Crashcoursefees:"+this.Crashcoursefees+", Crashduration:"+this.Crashduration;
		}
		@Override
		public double TotalFees()
		{
			System.out.println("calculate Toatal fees of CrashCourse.. ");
			return super.TotalFees()+(this.Crashcoursefees);
		}
		
		@Override
		public int Calduration()
		{
			System.out.println("Duration of Crash course ");
			return super.Calduration()+(this.Crashduration);
		}
}