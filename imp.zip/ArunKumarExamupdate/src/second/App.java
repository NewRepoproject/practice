package second;

public class App {
		public static void main(String[] args) {
	
//			Course s1 = new Course("Arun",1,"Java",30, 4000);
//			CrashCourse a1=new CrashCourse("Anup" ,1,"Java",2,4000,2000);
//					System.out.println(s1);
//					s1.display();
//					System.out.println(a1);
//					a1.display();
			
			
			Course c1=new Course("Arun",1,"Java",4000,120);
			System.out.println(c1);
			
			Course c2=new CrashCourse("Arun",1,"Java",4000,120,2000,50);
			System.out.println(c2);
			
			c1.Calduration();
			c2.Calduration();
			
		}
	}


