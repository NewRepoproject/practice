import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, throwError } from 'rxjs';
import { Book } from './model/book';
 
@Injectable({
  providedIn: 'root'
})
export class BookdaoService {
 
  baseurl:string;
 
  httpOptions = {
    headers:new HttpHeaders({
                             'Content-Type':'application/json'
                         })
   }
 
  constructor(private httpClient: HttpClient) {
 
    console.log('bookdao service constructor called...');
     this.baseurl = 'http://localhost:8081';
 
  //  this.httpClient = httpClient;
   }
 
   addBook(b:Book)
   {
     console.log('inside addBook method...');
    return this.httpClient.post<Book>(this.baseurl+"/addbook",JSON.stringify(b),this.httpOptions)
    .pipe(
      catchError(this.errorHandler)
      )
  
   }
 
   getAllBooks()
   {
      return this.httpClient.get<Book[]>(this.baseurl+"/allbooks",this.httpOptions).pipe(
        catchError(this.errorHandler)
      )
   }

   deleteBook(id : number){
    return this.httpClient.delete<Book>(this.baseurl+'/rembook/'+id).pipe(
      catchError(this.errorHandler)
    )
   }

   getById(id:number):Observable<Book>{
    return this.httpClient.get<Book>(this.baseurl+"/book/"+id,this.httpOptions).pipe(catchError(this.errorHandler))
   }

   updateBook(id:number,b:Book) {
    console.log("inside updatedBook method..");
    return this.httpClient.put<Book>(this.baseurl+"/bookupdate/"+id,JSON.stringify(b),this.httpOptions).pipe(
      catchError(this.errorHandler)
    )
   }
 
   errorHandler(httperror:HttpErrorResponse) {
    let errorMessage = '';
    if(httperror.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = httperror.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${httperror.status}\nMessage: ${httperror.message}`;
    }
    console.log(errorMessage);
    return throwError(() => httperror);
 }
   
 
}