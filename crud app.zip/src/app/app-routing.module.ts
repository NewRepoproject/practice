import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookformComponent } from './bookform/bookform.component';
import { BooklistComponent } from './booklist/booklist.component';
import { SearchComponent } from './search/search.component';
import { UpdateComponent } from './update/update.component';

const routes: Routes = [
  {
    path:'addBook',
    component:BookformComponent
  },
  {
    path:'listbooks',
    component:BooklistComponent
  },
  {
    path:'',
    redirectTo:'addBook',
    pathMatch:'full'
  },

  {
    path:'searchbook',
    component:SearchComponent
  },
  {
    path:'updateBook',
    component: UpdateComponent
  }



  
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
