import { Component ,OnInit} from '@angular/core';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  book:Book;
  bookdao:BookdaoService;

  constructor(bookdao:BookdaoService){

    this.book=new Book(1,"","");
    this.bookdao=bookdao;

  }

  ngOnInit(): void {
      
  }

  searchform(form:any){
    this.bookdao.getById(this.book.bookid).subscribe(
      ()=>{
        console.log("book with bookid:"+this.book.bookid+" is searched")
      }
    )
  }

}
