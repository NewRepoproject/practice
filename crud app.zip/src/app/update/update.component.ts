import { Component, OnInit } from '@angular/core';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  book: Book;
  bookdao: BookdaoService;
  constructor(bookdao: BookdaoService) {
    this.book= new Book(1,"","");
    this.bookdao = bookdao;
  }
  ngOnInit(): void {
  }
  updateform(form:any) {
    this.bookdao.updateBook(this.book.bookid,this.book).subscribe(
        ()=> {
            console.log("book updated successfully");
        }
    )
  }
}