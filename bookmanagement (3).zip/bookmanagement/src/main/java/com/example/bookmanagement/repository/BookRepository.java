package com.example.bookmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.bookmanagement.model.Book;


@Repository
public interface BookRepository extends JpaRepository<Book,Long> {

//	int deleteById(int bookid);

//	Object getById(int bookid);

//	void deleteById(int bookid);
	
	
	
}
