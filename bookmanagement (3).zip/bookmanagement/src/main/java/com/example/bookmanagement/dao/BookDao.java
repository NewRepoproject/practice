package com.example.bookmanagement.dao;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.bookmanagement.model.Book;
import com.example.bookmanagement.repository.BookRepository;


@Service
public class BookDao {
	private final BookRepository bookrepo;
	
	
	@Autowired
	public BookDao(BookRepository bookrepo) {
		this.bookrepo=bookrepo;
	}
	
	public Book addBook(Book b)
	{
		return bookrepo.save(b);
	}
	
	
	public List<Book> getAllBooks(){
		return bookrepo.findAll();
	}
	
	public Book updateBook(Book b)
	{
		return bookrepo.save(b);
	}

//	public int deleteBook(int bookid) {
//		return bookrepo.deleteById(bookid);// TODO Auto-generated method stub
//		
//	}
	
	
//	public Book getBook(int bookid)
//	{
//		
//		return  ((Book) bookrepo.getById(bookid));
////				.orElseThrow(() -> new BookNotFoundException("bookid:"+bookid+"not found"));
//	
//	}
//	
	
//	public void deleteBook(int bookid)
//	{
//		bookrepo.deleteById(bookid);
//	}
	
}
	
	
