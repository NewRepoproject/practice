package com.example.bookmanagement.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Book")
public class Book {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int bookid;
	@Column(name="Book Name")
	private String bookname;
	
	@Column(name="Book Author")
	private String bookauthor;

	
	
	public Book()
	{
		System.out.println("Book bean created..");
	}
	
	
	public Book(int bookid, String bookname,String bookauthor) {
		super();
		this.bookname = bookname;
		this.bookid = bookid;
		this.bookauthor = bookauthor;

	}
	
public int getBookid() {
		return bookid;
	}


	public void setBookid(int bookid) {
		this.bookid = bookid;
	}


	public String getBookname() {
		return bookname;
	}


	public void setBookname(String bookname) {
		this.bookname = bookname;
	}


	public String getBookauthor() {
		return bookauthor;
	}


	public void setBookauthor(String bookauthor) {
		this.bookauthor = bookauthor;
	}

	@Override
	public String toString() {
		return "Book [bookName=" + bookname + ", bookId=" + bookid + ", authorName=" + bookauthor +"]";
	}


	@Override
	public boolean equals(Object obj) {
		return  this.bookid == ((Book)obj).bookid;
	}
	
	
	

}

