package com.example.bookmanagement.restful;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.bookmanagement.dao.BookDao;
import com.example.bookmanagement.model.Book;

@RestController
@CrossOrigin(origins="*")
public class BookRestController {
	
	private final BookDao bookdao;
	
	public BookRestController(BookDao bookdao)
	{
		this.bookdao=bookdao;
	}

	
	@GetMapping("/all")
    public ResponseEntity<List<Book>> getAllBooks () {
        List<Book> b = bookdao.getAllBooks();
        return new ResponseEntity<>(b, HttpStatus.OK);
    }

//    @GetMapping("/find/{id}")
//    public ResponseEntity<Book> getBook (@PathVariable("bookid") int bookid) {
//        Book b = bookdao.getBook(bookid);
//        return new ResponseEntity<>(b, HttpStatus.OK);
//    }

    @PostMapping("/add")
    public ResponseEntity<Book> addBook(@RequestBody Book b) {
        Book newbook = bookdao.addBook(b);
        return new ResponseEntity<>(newbook, HttpStatus.CREATED);
    }

    @PutMapping("/update")
    public ResponseEntity<Book> updateBook(@RequestBody Book b) {
        Book updatebook = bookdao.updateBook(b);
        return new ResponseEntity<>(updatebook, HttpStatus.OK);
    }
//
//    @DeleteMapping("/delete/{bookid}")
//    public ResponseEntity<?> deleteBook(@PathVariable("bookid") int bookid) {
//        bookdao.deleteBook(bookid);
//        return new ResponseEntity<>(HttpStatus.OK);
//    }
}

