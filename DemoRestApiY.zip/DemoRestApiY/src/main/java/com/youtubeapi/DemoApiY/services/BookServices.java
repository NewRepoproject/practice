package com.youtubeapi.DemoApiY.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.youtubeapi.DemoApiY.entities.Book;
@Component
// or service
public class BookServices {
//	same as Bookdao
	private static List<Book> list=new ArrayList<>();
	static {
		list.add(new Book(12,"java","a"));
		list.add(new Book(13,"C++","b"));
		list.add(new Book(14,"python","c"));
	}
	
//	get all books
	public List<Book> getAllBooks()
	{
		return list;
	}
	
//	get single book by id
	public Book getBookById(int id)
	{
		Book book=null;
		book=list.stream().filter(e->e.getId()==id).findFirst().get();
//		this above is java 8 method that is used to match the given id with 
//		the book id in the list ,if match return that book ,else throw exception
		return book;
	}
	
//	adding the book
	public Book addBook(Book b){
		list.add(b);
		return b;
	}
	
//	delete book
	public void deleteBook(int bid)
	{
	list=list.stream().filter(book->book.getId()!=bid).collect(Collectors.toList());
// filter hota ha chatna ka lia 
	//	java stream api
//	if match it false
//	and notmatch then true
//	all the remaining book are store in the list and the one which match is deleted from the list 
//	.collect(Collectors.toList()) collect all the remaing book in the list and the new list data is store  in  the old one 
	
	}

//	update book
	public void updateBook(Book book, int bookId) {
		// TODO Auto-generated method stub
//		map will provide you one one object for updation
	list.stream().map(b->{
		if(b.getId()==bookId)
		{
			b.setTitle(book.getTitle());
			b.setAuthor(book.getAuthor());
		}
		return b;
	})
		.collect(Collectors.toList());
	}
		
		
	}


