package com.youtubeapi.DemoApiY.controller;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.StreamingHttpOutputMessage.Body;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.youtubeapi.DemoApiY.entities.Book;
import com.youtubeapi.DemoApiY.services.BookServices;

@RestController
public class Bookcontroller {
	@Autowired
	private BookServices bookService;
	
	
//	public Book getBooks() {
////		Book book=new Book();
////		book.setId(121);
////		book.setTitle("Java component reference");
////		book.setAuthor("xyz");
////		return book;
//		
//		return this.bookService.getAllBooks();
////	it giving as return type of getAllBooks is list	
//	}
//	
	
//	@GetMapping("/books")
//	public List<Book>getBooks(){
//		return this.bookService.getAllBooks();
//	}
//question @pathvariable ka work
//	upar this use hua yha nahi
	
	@GetMapping("/books")
	public ResponseEntity<List<Book>> getBooks(){
		
		List<Book> list=bookService.getAllBooks();
		if(list.size()<=0)
		{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();	
		}
		return ResponseEntity.of(Optional.of(list));	
	}
	
	
//	@GetMapping("/books/{id}")
//	public Book getBook(@PathVariable("id") int id) {
//		return bookService.getBookById(id);
//		
//	}
	
	@GetMapping("/books/{id}")
	public ResponseEntity<Book> getBook(@PathVariable("id") int id) {
		Book book= bookService.getBookById(id);
		
		
	}
	
	
//	create or add a book
	@PostMapping("/addbooks")
	public Book addBook(@RequestBody Book book)
	{
//		@RequestBody add all the data that are come in json format to book object created after (@RequestBody Book)
//		then we call the bookservise .addbook method in bookservice ,then the data in book object is passed to bookservice addbook method 
//		then that data is added to the list and return
		
		Book b=this.bookService.addBook(book);
		System.out.println(book);
		return b;
	}
	
//	delete book 
	@DeleteMapping("deletebooks/{bookId}")
	public void deletebook(@PathVariable("bookId") int bookId)
	{
		this.bookService.deleteBook(bookId);
//		
	}
	
//	update the book
	
	@PutMapping("updatebooks/{bookId}")
	public Book updateBook(@RequestBody Book book, @PathVariable("bookId") int bookId)
	{
//		book object contain the updated informaton 
	 this.bookService.updateBook(book,bookId);
	 System.out.println(book);
	 return book;
	}
}
